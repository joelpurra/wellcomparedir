﻿using System.Reflection;

[assembly: AssemblyTitle("WellCompareDir.Comparer")]
[assembly: AssemblyDescription("")]
